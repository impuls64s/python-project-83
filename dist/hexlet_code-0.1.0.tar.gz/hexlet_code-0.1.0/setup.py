# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['page_analyzer']

package_data = \
{'': ['*']}

install_requires = \
['flask>=2.2.2,<3.0.0', 'gunicorn>=20.1.0,<21.0.0']

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/impuls64s/python-project-83/workflows/hexlet-check/badge.svg)](https://github.com/impuls64s/python-project-83/actions)',
    'author': 'Oleg Cherkashin',
    'author_email': 'impuls_64@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.8,<4.0',
}


setup(**setup_kwargs)
